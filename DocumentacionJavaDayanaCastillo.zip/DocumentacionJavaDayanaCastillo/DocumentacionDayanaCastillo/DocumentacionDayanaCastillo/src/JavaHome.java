// Aqui se presentan los pasos que se van a segir durante este proceso
//  y que es lo que se va ir aprendiendo

//EJEMPLO
public class JavaHome {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}