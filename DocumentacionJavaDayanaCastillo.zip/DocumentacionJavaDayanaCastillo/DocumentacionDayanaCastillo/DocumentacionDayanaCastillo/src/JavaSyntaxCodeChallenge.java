public class JavaSyntaxCodeChallenge {
    public static void main(String[] args) {
        int a = 5, b = 3;
        System.out.println("Suma: " + (a + b));
    }
}
//SUMA es 8