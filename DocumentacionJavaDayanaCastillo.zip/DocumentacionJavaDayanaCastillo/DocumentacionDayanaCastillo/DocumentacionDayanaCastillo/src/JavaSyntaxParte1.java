// Es un conjunto de reglas que se debebe seguir al pie de la letra para que el programa se
//ejecute de manera correcta.

public class JavaSyntaxParte1 {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}

