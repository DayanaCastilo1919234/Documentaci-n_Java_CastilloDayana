// En este apartado se puede observar todo lo que se va a lograr durante el tutorial para
// aprender a usar correctamente java.

//EJEMPLO
public class JavaIntro {
  public static void main(String[] args) {
    String name = "";
    System.out.println("Hello " + name);
  }
}