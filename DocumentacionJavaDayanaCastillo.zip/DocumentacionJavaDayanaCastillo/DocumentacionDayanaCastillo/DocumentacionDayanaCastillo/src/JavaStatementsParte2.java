// Muestra que cada una de las centencias deben terminar siempre en ; o sino el 
// programa no puede ejecutar correctamente

//EJEMPLO

//Many Statements

public class JavaStatementsParte2 {
  public static void main(String[] args) {

    System.out.println("Hello World!");
System.out.println("Have a good day!");
System.out.println("Learning Java is fun!");  
    }
}

//Error

//System.out.println("Hello World!")
//System.out.println("Have a good day!")
//System.out.println("Learning Java is fun!")