//En esta parte nos muestra una pactica inicial de codigo basico para comprobar que
//las herramientas realmente funcionan.


public class JavaGettingStartedParte1QuickstartParte2 {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}