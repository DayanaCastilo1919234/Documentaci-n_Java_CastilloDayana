//Es basicamente la forma en la que se le pide a la computadora que agarre un dato que esta
//guardado en la memoria y lo muestre en pantalla.

//Display Variables

//Example

//String name = "John";
//System.out.println("Hello " + name);
//public class JavaPrintVariables {
public class JavaPrintVariables {
  public static void main(String[] args) {

    String firstName = "John ";
    String lastName = "Doe";
    String fullName = firstName + lastName;
    System.out.println(fullName);   
  }
}