//Es una instruccion que se le da al programa para que pueda
//ejecutar una accion especifica.

//EJEMPLO

//System.out.println("Java is fun!");

//example 
//System.out.println("Java is fun!")

public class JavaStatementsParte1 {

  public static void main(String[] args) {
    System.out.println("Java is fun!");
    }
}

//System.out.println("Java is fun!")
//error: ';' expected
