//Consiste en descargar e intalar el programa oficial de java en
//la computadora y configurar el editor de codigo

public class JavaGettingStartedParte1 {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}

